from flask import Flask, jsonify, json, url_for, render_template, request
import joblib
import os
import numpy as np
import matplotlib.pyplot as plt

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("home.html")


@app.route("/prediction")
def prediction():
    return render_template("prediction.html")


@app.route('/predict', methods=['POST', 'GET'])
def result():

    # item_weight= float(request.form['item_weight'])
    # item_fat_content=float(request.form['item_fat_content'])
    # item_visibility= float(request.form['item_visibility'])
    item_type = float(request.form['item_type'])
    item_mrp = float(request.form['item_mrp'])
    outlet_establishment_year = float(
        request.form['outlet_establishment_year'])
    # outlet_size= float(request.form['outlet_size'])
    outlet_location_type = float(request.form['outlet_location_type'])
    outlet_type = float(request.form['outlet_type'])

    X = np.array([[item_type, item_mrp,
                  outlet_establishment_year, outlet_location_type, outlet_type]])

    scaler_path = r'C:\Users\jateen\Desktop\ML\env\BigMart-Sales-Prediction-With-Deployment\models\sc.sav'

    sc = joblib.load(scaler_path)

    X_std = sc.transform(X)

    model_path = r'C:\Users\jateen\Desktop\ML\env\BigMart-Sales-Prediction-With-Deployment\models\lr.sav'

    model = joblib.load(model_path)

    Y_pred = model.predict(X_std)

    sales_item = int(int(Y_pred) / item_mrp)

    # Calculate actual value based on predicted value
    actual_value = int(Y_pred) + item_mrp

    # Create a bar chart of actual vs predicted values
    labels = ['Actual', 'Predicted']
    values = [actual_value, int(Y_pred)]

    plt.bar(labels, values)
    plt.xlabel('Value')
    plt.ylabel('Sales')
    plt.title('Actual vs Predicted Sales')
    plt.show()

    return render_template('predict.html', predict1=int(Y_pred), mrp=sales_item, actual=actual_value)

    # return jsonify({'Prediction': float(Y_pred)})


if __name__ == "__main__":
    app.run(debug=True)
